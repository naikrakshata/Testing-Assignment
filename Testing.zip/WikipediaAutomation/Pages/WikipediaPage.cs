using OpenQA.Selenium;

namespace WikipediaAutomation.Pages
{
    public class WikipediaPage
    {
        private readonly IWebDriver driver;

        private const string WikipediaUrl = "https://en.wikipedia.org/wiki/Test_automation";
        private readonly By TestDrivenSection = By.XPath("//span[@id='Test-driven_development']/ancestor::h3/following-sibling::p");

        public WikipediaPage(IWebDriver webDriver)
        {
            driver = webDriver;
        }

        public void NavigateToPage()
        {
            driver.Navigate().GoToUrl(WikipediaUrl);
        }

        public string GetTestDrivenDevelopmentText()
        {
            return driver.FindElement(TestDrivenSection).Text;
        }
    }
}