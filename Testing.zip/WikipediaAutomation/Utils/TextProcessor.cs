using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace WikipediaAutomation.Utils
{
    public static class TextProcessor
    {
        public static Dictionary<string, int> ProcessText(string input)
        {
            string cleaned = Regex.Replace(input, @"\[[^\]]*\]", "");
            cleaned = Regex.Replace(cleaned, @"[^\w\s]", " ");
            cleaned = cleaned.ToLower();
            var words = cleaned.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            return words.GroupBy(w => w)
                        .ToDictionary(g => g.Key, g => g.Count());
        }
    }
}