using NUnit.Framework;
using OpenQA.Selenium;
using WikipediaAutomation.Drivers;
using WikipediaAutomation.Pages;
using WikipediaAutomation.Utils;
using System;

namespace WikipediaAutomation.Tests
{
    [TestFixture]
    public class WikipediaTests
    {
        private IWebDriver driver;
        private WikipediaPage wikiPage;

        [SetUp]
        public void Setup()
        {
            driver = WebDriverFactory.GetDriver();
            wikiPage = new WikipediaPage(driver);
        }

        [Test]
        public void ExtractAndCountWords()
        {
            wikiPage.NavigateToPage();
            string sectionText = wikiPage.GetTestDrivenDevelopmentText();
            Console.WriteLine("Extracted Text: " + sectionText);

            var wordCount = TextProcessor.ProcessText(sectionText);
            foreach (var kvp in wordCount)
            {
                Console.WriteLine($"{kvp.Key} : {kvp.Value}");
            }

            Assert.IsNotEmpty(wordCount);
        }

        [TearDown]
        public void Cleanup()
        {
            WebDriverFactory.QuitDriver();
        }
    }
}